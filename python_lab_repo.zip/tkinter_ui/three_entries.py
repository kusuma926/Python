# tkinter_ui/three_entries.py
import tkinter as tk
root=tk.Tk(); root.title('Text-Box Input')
entries=[]
for i in range(3):
    tk.Label(root, text=f'Enter value {i+1}:').pack()
    e=tk.Entry(root); e.pack()
    entries.append(e)
def get_values():
    for i,e in enumerate(entries,1):
        print(f'Value {i}:', e.get())
tk.Button(root, text='Submit', command=get_values).pack()
root.mainloop()
