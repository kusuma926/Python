# tkinter_ui/label_font.py
import tkinter as tk
def change_font():
    label.config(font=('Arial',18,'bold'))
root=tk.Tk()
label=tk.Label(root, text='Hello, World!', font=('Helvetica',14))
label.pack()
btn=tk.Button(root, text='Change Font', command=change_font)
btn.pack()
root.mainloop()
