# file_ops/count_errors.py
def count_error_lines(filename):
    count=0
    with open(filename,'r') as f:
        for line in f:
            if 'ERROR' in line:
                count+=1
    return count

if __name__=='__main__':
    # ensure log.txt exists by calling write_and_read or create a sample
    with open('log.txt','a') as f:
        f.write('ERROR: sample error line\n')
    print('Number of lines with ERROR:', count_error_lines('log.txt'))
