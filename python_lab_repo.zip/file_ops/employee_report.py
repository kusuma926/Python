# file_ops/employee_report.py
def write_employee_report(filename):
    employees=[{'name':'Alice','department':'HR'},
               {'name':'Bob','department':'Engineering'}]
    with open(filename,'w') as f:
        for e in employees:
            f.write(f"Name: {e['name']}, Department: {e['department']}\n")

if __name__=='__main__':
    write_employee_report('employee_report.txt')
    print('Wrote employee_report.txt')
