# file_ops/write_and_read.py
def writefile():
    text = ('Error objects are thrown when runtime errors occur. '
            'The Error object can also be used as a base object for user-defined exceptions.')
    with open('log.txt', 'w') as f:
        f.write(text + '\n')

def readfile(filename):
    with open(filename,'r') as f:
        print(f.read())

if __name__=='__main__':
    writefile()
    print('Contents of log.txt:')
    readfile('log.txt')
