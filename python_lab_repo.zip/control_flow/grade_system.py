# control_flow/grade_system.py
score = int(input('Enter the score (0-100): '))
if score >= 90:
    print('The Grade is A')
elif score >= 80:
    print('The Grade is B')
elif score >= 70:
    print('The Grade is C')
elif score >= 60:
    print('The Grade is D')
else:
    print('The Grade is F')
