# control_flow/first_10_natural.py
print('The first 10 natural numbers are:')
for i in range(1,11):
    print(i)
