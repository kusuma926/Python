# Python Lab Programs
This repository contains Python programs for the lab manual tasks provided by the user.
Folders:
- basics: simple input/output and operators
- control_flow: conditionals and loops
- modules_package: example module and package
- data_structures: lists, tuples, dicts
- searching_sorting: search & bubble sort examples
- file_ops: text file operations
- functions: functions and calculator
- generators_decorators: generators and decorators
- exceptions: exception handling examples
- plotting: matplotlib examples
- tkinter_ui: simple Tkinter GUIs
- pygame_games: simple pygame examples (snake & chess board)
