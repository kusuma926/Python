# basics/calculator_input.py
# Enter two numbers and perform basic arithmetic operations.
def main():
    x = int(input('Enter the first number: '))
    y = int(input('Enter the second number: '))
    print('Addition:', x+y)
    print('Subtraction:', x-y)
    print('Multiplication:', x*y)
    try:
        print('Division:', x/y)
    except ZeroDivisionError:
        print('Division: Error (division by zero)')

if __name__ == '__main__':
    main()
