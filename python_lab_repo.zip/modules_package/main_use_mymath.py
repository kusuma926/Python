# modules_package/main_use_mymath.py
import mymath
a,b = 10,5
print('Addition:', mymath.add(a,b))
print('Subtraction:', mymath.subtract(a,b))
print('Multiplication:', mymath.multiply(a,b))
print('Division:', mymath.divide(a,b))
