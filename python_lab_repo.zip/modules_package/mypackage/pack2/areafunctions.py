import math
def circle_area(r): return math.pi * r * r
def rectangle_area(l,w): return l*w
def triangle_area(b,h): return 0.5*b*h
