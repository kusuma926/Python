# package initializer for mypackage
