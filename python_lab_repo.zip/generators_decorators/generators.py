# generators_decorators/generators.py
def number_sequence(start=0, end=10, step=1):
    current = start
    while current <= end:
        yield current
        current += step

if __name__=='__main__':
    for n in number_sequence(1,10,2):
        print(n)
