# data_structures/lists_tuples_dicts.py
# list ops
l=[10,20]
l.append(30)
print('List after append:', l)
l.pop(1)
print('After pop index 1:', l)
l.remove(10)
print('After remove 10:', l)
l2=[5,8,9,15,30,89]
print('Sorted:', sorted(l2))
print('Min:', min(l2), 'Max:', max(l2), 'Sum:', sum(l2))

# tuple ops
t=(10,'hello',3.14,'world')
print('Tuple:', t)
print('Slice t[1:3]:', t[1:3])
t2=(5,0.5)
print('Concat:', t + t2)

# dict ops
d={'name':'Alice','age':30,'city':'New York'}
print('Dict:', d)
print('Name:', d['name'])
d['name']='James'
d.pop('city', None)
print('Updated dict:', d)
