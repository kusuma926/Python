# functions/calculator_functions.py
def add(a,b): return a+b
def subtract(a,b): return a-b
def multiply(a,b): return a*b
def divide(a,b):
    if b==0: return 'Error: Division by zero'
    return a/b
def greet(name): return f'Hello, {name}!'
if __name__=='__main__':
    print('Sum:', add(10,5))
    print('Quotient:', divide(10,5))
    print(greet('Alice'))
