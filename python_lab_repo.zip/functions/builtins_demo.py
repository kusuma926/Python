# functions/builtins_demo.py
def analyze_student_grades():
    student_names=['Alice','Bob','Charlie','Diana']
    student_grades=[85,92,78,90]
    print('Number of students:', len(student_names))
    print('Type of names:', type(student_names))
    print('Highest grade:', max(student_grades))
    print('Lowest grade:', min(student_grades))
    print('Sorted grades:', sorted(student_grades))
    print('Reversed grades:', list(reversed(sorted(student_grades))))
    print('Grade indices:', list(range(1, len(student_names)+1)))

if __name__=='__main__':
    analyze_student_grades()
