# pygame_games/chess_board.py
import pygame, sys
pygame.init()
size=640; screen=pygame.display.set_mode((size,size))
pygame.display.set_caption('Chess Board')
white=(255,255,255); brown=(153,76,0)
def draw_board():
    sq=size//8
    for r in range(8):
        for c in range(8):
            color = white if (r+c)%2==0 else brown
            pygame.draw.rect(screen, color, (c*sq, r*sq, sq, sq))
while True:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit(); sys.exit()
    draw_board()
    pygame.display.flip()
