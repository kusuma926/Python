# exceptions/division_exception.py
def divide_numbers():
    try:
        numerator=float(input('Numerator: '))
        denominator=float(input('Denominator: '))
        print('Result:', numerator/denominator)
    except ZeroDivisionError:
        print('Error: Division by zero is not allowed.')
    except ValueError:
        print('Enter valid numbers.')
if __name__=='__main__':
    divide_numbers()
