# exceptions/custom_exception.py
class InvalidAgeException(Exception):
    pass

try:
    age=int(input('Enter age: '))
    if age<18:
        raise InvalidAgeException('Invalid Age')
    print('Eligible to Vote')
except InvalidAgeException as e:
    print('Exception occurred:', e)
