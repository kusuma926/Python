# exceptions/index_error_demo.py
grades=[85,90,78,92,88]
print('Grades List:', grades)
try:
    index=int(input('Enter index: '))
    print('Grade:', grades[index])
except IndexError:
    print('Invalid index.')
except ValueError:
    print('Please enter a number.')
