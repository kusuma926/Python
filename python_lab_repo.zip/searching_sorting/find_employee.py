# searching_sorting/find_employee.py
def find_employee_by_id(employees, target_id):
    for emp in employees:
        if emp.get('id')==target_id:
            return emp
    return None

if __name__=='__main__':
    employees = [
        {'id':1,'name':'Alice','department':'HR'},
        {'id':2,'name':'Bob','department':'Engineering'},
        {'id':3,'name':'Charlie','department':'Sales'}
    ]
    print(find_employee_by_id(employees,2))
